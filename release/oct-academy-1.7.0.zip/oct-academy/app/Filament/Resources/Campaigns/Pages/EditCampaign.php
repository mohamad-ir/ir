<?php

namespace App\Filament\Resources\Campaigns\Pages;

use App\Enums\CampaignStatus;
use App\Filament\Concerns\TranslatesPageLabels;
use App\Filament\Resources\Campaigns\CampaignResource;
use App\Models\ActivityLog;
use App\Services\Newsletter\CampaignSender;
use Filament\Actions\Action;
use Filament\Actions\DeleteAction;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\EditRecord;
use Throwable;

class EditCampaign extends EditRecord
{
    use TranslatesPageLabels;

    protected static string $resource = CampaignResource::class;

    public function isSending(): bool
    {
        return $this->record->status === CampaignStatus::Sending;
    }

    /** Polled from the status panel while the dashboard is open, so sending progresses even without cron. */
    public function processBatch(): void
    {
        if (! $this->isSending()) {
            return;
        }
        app(CampaignSender::class)->sendBatch($this->record);
        $this->record->refresh();
        if ($this->record->status === CampaignStatus::Sent) {
            Notification::make()->success()->title(__('Campaign sent to :count subscribers', ['count' => number_format($this->record->sent_count)]))->send();
        }
    }

    protected function getHeaderActions(): array
    {
        $editable = fn () => in_array($this->record->status, [CampaignStatus::Draft, CampaignStatus::Scheduled, CampaignStatus::Cancelled], true);

        return [
            Action::make('test')->label(__('Send test'))->icon('heroicon-o-beaker')->color('gray')
                ->schema([TextInput::make('email')->email()->required()->default(fn () => auth()->user()->email)])
                ->action(function (array $data) {
                    $this->save(false);
                    try {
                        app(CampaignSender::class)->sendTest($this->record, $data['email']);
                        Notification::make()->success()->title(__('Test email sent to :email', ['email' => $data['email']]))->send();
                    } catch (Throwable $e) {
                        Notification::make()->danger()->title(__('Could not send the test'))->body($e->getMessage())->persistent()->send();
                    }
                }),
            Action::make('schedule')->label(__('Schedule'))->icon('heroicon-o-calendar')->color('gray')->visible($editable)
                ->schema([DateTimePicker::make('scheduled_at')->required()->native(false)->minDate(now())->seconds(false)->timezone(config('app.display_timezone', config('app.timezone')))])
                ->action(function (array $data) {
                    $this->save(false);
                    $this->record->update(['status' => CampaignStatus::Scheduled, 'scheduled_at' => $data['scheduled_at']]);
                    Notification::make()->success()->title(__('Scheduled for :date', ['date' => $this->record->scheduled_at->timezone(config('app.display_timezone', config('app.timezone')))->format('j M Y H:i')]))->body(__('Sending requires the cron job described in the installation guide.'))->send();
                }),
            Action::make('send')->label(__('Send now'))->icon('heroicon-o-paper-airplane')->visible($editable)
                ->requiresConfirmation()
                ->modalHeading(__('Send this campaign now?'))
                ->modalDescription(fn () => __('It will be sent to :count confirmed subscribers in batches of :rate per minute.', ['count' => number_format(app(CampaignSender::class)->audienceQuery($this->record)->count()), 'rate' => setting('newsletter.send_rate_per_minute', 20)]))
                ->action(function () {
                    $this->save(false);
                    $count = app(CampaignSender::class)->start($this->record->fresh());
                    $this->record->refresh();
                    if ($this->record->status !== CampaignStatus::Sending) {
                        Notification::make()->warning()->title(__('Sending could not start'))->send();

                        return;
                    }
                    ActivityLog::record('campaign_sent', 'Campaign “'.$this->record->subject.'” started ('.$count.' recipients)', $this->record);
                    Notification::make()->success()->title(__('Sending started'))->body(__('Keep this page open or rely on the cron job to finish sending.'))->send();
                }),
            Action::make('cancel')->label(__('Stop sending'))->color('danger')->visible(fn () => $this->isSending() || $this->record->status === CampaignStatus::Scheduled)
                ->requiresConfirmation()
                ->action(function () {
                    $this->record->update(['status' => CampaignStatus::Cancelled]);
                    $this->record->recipients()->where('status', 'pending')->delete();
                }),
            DeleteAction::make()->visible($editable),
        ];
    }
}
