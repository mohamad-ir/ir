<?php

namespace App\Services\Payments;

use App\Enums\OrderStatus;
use App\Enums\SubscriptionStatus;
use App\Mail\MembershipStarted;
use App\Models\Certificate;
use App\Models\Course;
use App\Models\MembershipPlan;
use App\Models\Order;
use App\Models\Subscription;
use App\Models\User;
use App\Models\Webinar;
use App\Services\Access\ContentAccess;
use App\Services\Learning\LearningService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * Turns Stripe events into access. Every method is idempotent: the same event
 * may arrive more than once (webhook retries) and the success page also calls
 * fulfilCheckoutSession() so access is granted even if webhooks are delayed.
 *
 * Handles both the classic and the 2025 ("basil") Stripe object shapes, because
 * webhook payloads use the API version configured on the Stripe account.
 */
class Fulfillment
{
    /** Events the webhook endpoint subscribes to. */
    public const EVENTS = [
        'checkout.session.completed', 'checkout.session.async_payment_succeeded', 'checkout.session.async_payment_failed', 'checkout.session.expired',
        'customer.subscription.created', 'customer.subscription.updated', 'customer.subscription.deleted', 'customer.subscription.paused', 'customer.subscription.resumed',
        'invoice.paid', 'charge.refunded', 'charge.dispute.closed',
    ];

    public function __construct(protected StripeClient $stripe, protected LearningService $learning) {}

    public function handle(array $event): void
    {
        $object = $event['data']['object'] ?? [];
        $created = self::time($event['created'] ?? null);

        match ($event['type'] ?? null) {
            'checkout.session.completed', 'checkout.session.async_payment_succeeded' => $this->fulfilCheckoutSession($object),
            'checkout.session.async_payment_failed' => $this->failCheckoutSession($object, OrderStatus::Failed),
            'checkout.session.expired' => $this->failCheckoutSession($object, OrderStatus::Canceled),
            'customer.subscription.created', 'customer.subscription.updated', 'customer.subscription.deleted',
            'customer.subscription.paused', 'customer.subscription.resumed' => $this->syncSubscription($object, [], $created),
            'invoice.paid' => $this->recordInvoice($object),
            'charge.refunded' => $this->recordRefund($object),
            'charge.dispute.closed' => $this->recordDispute($object),
            default => null,
        };
    }

    // Checkout ---------------------------------------------------------------

    public function fulfilCheckoutSession(array $session): void
    {
        $metadata = $session['metadata'] ?? [];
        $type = $metadata['type'] ?? null;

        if ($type === 'membership') {
            $subscriptionId = self::id($session['subscription'] ?? null);
            if ($subscriptionId) {
                // Read when the session is handled, so this is the current state.
                $subscription = is_array($session['subscription'] ?? null) ? $session['subscription'] : $this->stripe->get('subscriptions/'.$subscriptionId);
                $this->syncSubscription($subscription, $metadata, now());
            }

            return;
        }

        if (! in_array($type, ['course', 'webinar'], true)) {
            return;
        }

        // Asynchronous methods (e.g. SEPA Direct Debit) complete the session before the money arrives.
        // ("no_payment_required": a 100% promotion code.)
        if (! self::isPaid($session)) {
            return;
        }

        DB::transaction(function () use ($session, $metadata, $type) {
            $order = Order::lockForUpdate()->find($metadata['order_id'] ?? 0)
                ?? Order::lockForUpdate()->where('stripe_checkout_session_id', $session['id'])->first();
            if (! $order || $order->isPaid() || in_array($order->status, [OrderStatus::Refunded], true)) {
                return;
            }

            $details = $session['total_details'] ?? [];
            $order->update([
                'status' => OrderStatus::Paid,
                'paid_at' => now(),
                'stripe_checkout_session_id' => $session['id'],
                'stripe_payment_intent_id' => self::id($session['payment_intent'] ?? null),
                'stripe_invoice_id' => self::id($session['invoice'] ?? null),
                'total' => $session['amount_total'] ?? $order->total,
                'subtotal' => $session['amount_subtotal'] ?? $order->subtotal,
                'tax' => $details['amount_tax'] ?? 0,
                'currency' => strtoupper($session['currency'] ?? $order->currency),
                'meta' => array_filter([
                    ...($order->meta ?? []),
                    'discount' => $details['amount_discount'] ?? null,
                    'customer_country' => $session['customer_details']['address']['country'] ?? null,
                    'tax_ids' => collect($session['customer_details']['tax_ids'] ?? [])->pluck('value')->all() ?: null,
                ]),
            ]);

            $user = $order->user ?? User::find($metadata['user_id'] ?? 0);
            if (! $user) {
                Log::warning("Paid order {$order->number} has no user to grant access to.");

                return;
            }

            // Paid twice for the same item (two tabs, an old Checkout page): flag it for a refund in the dashboard.
            $earlier = Order::where('user_id', $user->id)->where('id', '!=', $order->id)
                ->where('purchasable_type', $order->purchasable_type)->where('purchasable_id', $order->purchasable_id)
                ->where('status', OrderStatus::Paid)->value('number');
            if ($earlier) {
                $order->update(['meta' => [...($order->meta ?? []), 'duplicate_of' => $earlier]]);
                Log::warning("Order {$order->number} pays again for an item already bought in {$earlier}; consider refunding it.");
            }

            if ($type === 'course' && ($course = Course::withTrashed()->find($order->purchasable_id))) {
                $this->learning->enroll($user, $course, 'purchase', $order);
            }
            if ($type === 'webinar' && ($webinar = Webinar::withTrashed()->find($order->purchasable_id))) {
                $this->learning->register($user, $webinar, 'purchase', $order);
            }
        });

        $this->attachReceipt($metadata['order_id'] ?? null);
    }

    protected function failCheckoutSession(array $session, OrderStatus $status): void
    {
        Order::where('stripe_checkout_session_id', $session['id'] ?? '')->where('status', OrderStatus::Pending)->update(['status' => $status]);
    }

    /** Adds Stripe's hosted receipt link to the order (best effort). */
    protected function attachReceipt(int|string|null $orderId): void
    {
        $order = $orderId ? Order::find($orderId) : null;
        if (! $order || $order->receipt_url || ! $order->stripe_payment_intent_id) {
            return;
        }

        try {
            $intent = $this->stripe->get('payment_intents/'.$order->stripe_payment_intent_id, ['expand' => ['latest_charge']]);
            $order->update(['receipt_url' => $intent['latest_charge']['receipt_url'] ?? null]);
        } catch (StripeException $e) {
            Log::info('Receipt link unavailable for '.$order->number.': '.$e->getMessage());
        }
    }

    // Subscriptions -----------------------------------------------------------

    /**
     * @param  Carbon|null  $stateAt  when this state was true (event creation time, or now for a fresh API read);
     *                                an older state never overwrites a newer one (Stripe sends events out of order and retries for days)
     */
    public function syncSubscription(array $data, array $sessionMetadata = [], ?Carbon $stateAt = null): ?Subscription
    {
        $metadata = ($data['metadata'] ?? []) + $sessionMetadata;
        $customerId = self::id($data['customer'] ?? null);

        $user = User::find($metadata['user_id'] ?? 0)
            ?? ($customerId ? User::where('stripe_customer_id', $customerId)->first() : null);
        if (! $user) {
            Log::warning('Stripe subscription '.($data['id'] ?? '?').' does not match a user.');

            return null;
        }

        $item = $data['items']['data'][0] ?? [];
        $price = $item['price'] ?? [];
        $plan = MembershipPlan::find($metadata['plan_id'] ?? 0)
            ?? (isset($price['id']) ? MembershipPlan::all()->first(fn (MembershipPlan $p) => $p->stripe_price_id === $price['id']
                || collect($p->stripe_prices ?? [])->pluck('id')->contains($price['id'])) : null);

        $status = SubscriptionStatus::tryFrom($data['status'] ?? '') ?? SubscriptionStatus::Incomplete;

        // The success page and several webhooks can create the same row at once: insert first (ignored when it
        // exists), then lock the existing row; deadlocks are retried.
        Subscription::query()->insertOrIgnore(['stripe_subscription_id' => $data['id'], 'user_id' => $user->id, 'status' => SubscriptionStatus::Incomplete->value, 'created_at' => now(), 'updated_at' => now()]);

        return DB::transaction(function () use ($data, $user, $plan, $status, $item, $price, $customerId, $stateAt) {
            $subscription = Subscription::lockForUpdate()->where('stripe_subscription_id', $data['id'])->firstOrFail();
            if ($stateAt && $subscription->stripe_synced_at && $stateAt->lt($subscription->stripe_synced_at)) {
                return $subscription; // an older event arriving late
            }
            $wasGranting = $subscription->grantsAccess();
            $neverGranted = in_array($subscription->status, [SubscriptionStatus::Incomplete, null], true);

            $subscription->fill([
                'user_id' => $user->id,
                'membership_plan_id' => $plan?->id ?? $subscription->membership_plan_id,
                'stripe_customer_id' => $customerId,
                'status' => $status,
                'amount' => $price['unit_amount'] ?? $subscription->amount,
                'currency' => isset($price['currency']) ? strtoupper($price['currency']) : $subscription->currency,
                'interval' => $price['recurring']['interval'] ?? $subscription->interval,
                'current_period_end' => self::time($data['current_period_end'] ?? $item['current_period_end'] ?? null),
                'trial_ends_at' => self::time($data['trial_end'] ?? null),
                'cancel_at_period_end' => (bool) ($data['cancel_at_period_end'] ?? false) || filled($data['cancel_at'] ?? null),
                'canceled_at' => self::time($data['canceled_at'] ?? null),
                'ended_at' => self::time($data['ended_at'] ?? null),
                'stripe_synced_at' => $stateAt ?? $subscription->stripe_synced_at,
            ])->save();

            if (! $user->stripe_customer_id && $customerId) {
                $user->forceFill(['stripe_customer_id' => $customerId])->saveQuietly();
            }
            $user->forgetMembership();

            if (! $wasGranting && $neverGranted && $subscription->grantsAccess()) {
                $this->learning->mail($user, new MembershipStarted($subscription));
            }

            return $subscription;
        }, attempts: 3);
    }

    /** Each paid membership invoice becomes an order, so revenue reports include renewals. */
    public function recordInvoice(array $invoice): void
    {
        $subscriptionId = self::id($invoice['subscription'] ?? $invoice['parent']['subscription_details']['subscription'] ?? null);
        if (! $subscriptionId || ! isset($invoice['id']) || (int) ($invoice['amount_paid'] ?? 0) === 0) {
            return; // one-time purchases are recorded from Checkout; €0 trial invoices are skipped
        }

        $customerId = self::id($invoice['customer'] ?? null);
        $subscription = Subscription::where('stripe_subscription_id', $subscriptionId)->first();
        $user = $subscription?->user ?? ($customerId ? User::where('stripe_customer_id', $customerId)->first() : null);
        $plan = $subscription?->plan;

        $tax = (int) ($invoice['tax'] ?? collect($invoice['total_taxes'] ?? [])->sum('amount'));

        Order::firstOrCreate(['stripe_invoice_id' => $invoice['id']], [
            'user_id' => $user?->id,
            'email' => $invoice['customer_email'] ?? $user?->email ?? 'unknown',
            'name' => $invoice['customer_name'] ?? $user?->name,
            'type' => 'membership',
            'purchasable_type' => $plan ? $plan->getMorphClass() : null,
            'purchasable_id' => $plan?->id,
            'description' => ($plan?->name ?? 'Membership').' — '.(($invoice['billing_reason'] ?? '') === 'subscription_create' ? 'first payment' : 'renewal'),
            'subtotal' => (int) ($invoice['subtotal'] ?? $invoice['amount_paid']),
            'tax' => $tax,
            'total' => (int) $invoice['amount_paid'],
            'currency' => strtoupper($invoice['currency'] ?? 'EUR'),
            'status' => OrderStatus::Paid,
            'stripe_subscription_id' => $subscriptionId,
            'stripe_payment_intent_id' => $this->invoicePaymentIntent($invoice),
            'receipt_url' => $invoice['hosted_invoice_url'] ?? null,
            'invoice_pdf_url' => $invoice['invoice_pdf'] ?? null,
            'paid_at' => self::time($invoice['status_transitions']['paid_at'] ?? null) ?? now(),
        ]);
    }

    /**
     * The payment behind an invoice. Older API versions put it on the invoice; since 2025-03-31
     * ("basil") it is listed in invoice.payments, which webhooks only include when expanded.
     */
    protected function invoicePaymentIntent(array $invoice): ?string
    {
        $direct = self::id($invoice['payment_intent'] ?? null);
        if ($direct) {
            return $direct;
        }
        $payments = $invoice['payments']['data'] ?? null;
        if ($payments === null && isset($invoice['id'])) {
            try {
                $payments = $this->stripe->get('invoices/'.$invoice['id'], ['expand' => ['payments']])['payments']['data'] ?? [];
            } catch (StripeException $e) {
                Log::warning('Could not read the payments of invoice '.$invoice['id'].': '.$e->getMessage());
                $payments = [];
            }
        }
        foreach ($payments as $payment) {
            if ($id = self::id($payment['payment']['payment_intent'] ?? null)) {
                return $id;
            }
        }

        return null;
    }

    // Refunds -----------------------------------------------------------------

    public function recordRefund(array $charge): void
    {
        $intentId = self::id($charge['payment_intent'] ?? null);
        $order = $intentId ? Order::where('stripe_payment_intent_id', $intentId)->first() : null;
        $order ??= isset($charge['invoice']) ? Order::where('stripe_invoice_id', self::id($charge['invoice']))->first() : null;
        if (! $order) {
            return;
        }

        $this->applyRefund($order, (int) ($charge['amount_refunded'] ?? 0));
    }

    /** A lost chargeback is treated like a full refund (access bought by that payment ends). */
    public function recordDispute(array $dispute): void
    {
        $intentId = self::id($dispute['payment_intent'] ?? null);
        $order = $intentId ? Order::where('stripe_payment_intent_id', $intentId)->first() : null;
        if (! $order) {
            return;
        }
        $order->update(['meta' => [...($order->meta ?? []), 'dispute' => $dispute['status'] ?? 'closed']]);
        if (($dispute['status'] ?? null) === 'lost') {
            $this->applyRefund($order, $order->total);
        }
    }

    public function applyRefund(Order $order, int $refundedTotal): void
    {
        $full = $refundedTotal >= $order->total;
        $order->update([
            'refunded_amount' => min($refundedTotal, $order->total),
            'status' => $full ? OrderStatus::Refunded : OrderStatus::PartiallyRefunded,
            'refunded_at' => now(),
        ]);

        // A full refund of a course or ticket removes the access it bought.
        if ($full) {
            $this->learning->revokeEnrollment($order);
            $this->learning->revokeRegistration($order);
            $this->revokeCertificate($order);
        }
    }

    /** A course certificate earned with access that was refunded is no longer valid (unless access remains another way). */
    protected function revokeCertificate(Order $order): void
    {
        if ($order->type !== 'course' || ! $order->user || ! ($course = Course::withTrashed()->find($order->purchasable_id))) {
            return;
        }
        if (app(ContentAccess::class)->canAccessCourse($course, $order->user->fresh())) {
            return;
        }
        Certificate::where('user_id', $order->user_id)->where('course_id', $course->id)->whereNull('revoked_at')
            ->update(['revoked_at' => now(), 'revoke_reason' => 'Payment refunded ('.$order->number.')']);
    }

    // Helpers -----------------------------------------------------------------

    /** A Checkout session whose money has arrived, or that needed none (100% promotion code). */
    public static function isPaid(array $session): bool
    {
        return in_array($session['payment_status'] ?? null, ['paid', 'no_payment_required'], true);
    }

    /** Stripe fields may be an ID string or an expanded object. */
    public static function id(mixed $value): ?string
    {
        return is_array($value) ? ($value['id'] ?? null) : (is_string($value) && $value !== '' ? $value : null);
    }

    public static function time(mixed $timestamp): ?Carbon
    {
        return is_numeric($timestamp) && $timestamp > 0 ? Carbon::createFromTimestamp((int) $timestamp) : null;
    }
}
