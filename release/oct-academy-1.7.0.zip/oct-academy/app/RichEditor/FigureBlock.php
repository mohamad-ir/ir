<?php

namespace App\RichEditor;

use App\Filament\Forms\MediaPicker;
use App\Models\Media;
use App\Support\Ui;
use Filament\Actions\Action;
use Filament\Forms\Components\RichEditor\RichContentCustomBlock;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;

/** Responsive figure from the media library with caption and credit. */
class FigureBlock extends RichContentCustomBlock
{
    public static function getId(): string
    {
        return 'figure';
    }

    public static function getLabel(): string
    {
        return __('Figure from media library');
    }

    public static function getIcon(): string
    {
        return 'heroicon-o-photo';
    }

    public static function configureEditorAction(Action $action): Action
    {
        return $action
            ->modalDescription(__('Insert an optimised, responsive image with a numbered caption.'))
            ->schema([
                MediaPicker::make('media_id')->label(__('Image'))->required(),
                Textarea::make('caption')->rows(2)->helperText(__('Leave empty to use the caption saved in the media library.')),
                Select::make('size')->options(Ui::options(['normal' => 'Text width', 'wide' => 'Wide', 'full' => 'Full width']))->default('normal'),
            ]);
    }

    public static function getPreviewLabel(array $config): string
    {
        $media = Media::find($config['media_id'] ?? null);

        return __('Figure').': '.($media?->title ?: $media?->original_name ?: __('missing image'));
    }

    public static function toPreviewHtml(array $config): ?string
    {
        $media = Media::find($config['media_id'] ?? null);

        return $media ? '<img src="'.e($media->thumbUrl()).'" style="max-height:12rem;border-radius:.5rem" alt="">' : null;
    }

    public static function toHtml(array $config, array $data): string
    {
        $media = Media::find($config['media_id'] ?? null);
        if (! $media) {
            return '';
        }

        $size = in_array($config['size'] ?? 'normal', ['normal', 'wide', 'full']) ? $config['size'] : 'normal';
        $caption = trim($config['caption'] ?? '') ?: $media->caption;
        $credit = $media->credit ? ' <span class="figure-credit">'.e($media->credit).'</span>' : '';
        $sizes = ['normal' => '(min-width: 1024px) 860px, 100vw', 'wide' => '(min-width: 1024px) 990px, 100vw', 'full' => '100vw'][$size];
        $srcset = $media->srcset() ? ' srcset="'.e($media->srcset()).'" sizes="'.$sizes.'"' : '';
        $dims = $media->width ? " width=\"{$media->width}\" height=\"{$media->height}\"" : '';

        return '<figure class="figure figure-'.$size.'"><img src="'.e($media->url(isset($media->variants['lg']) ? 'lg' : null)).'"'.$srcset.$dims.' alt="'.e($media->altText()).'" loading="lazy" decoding="async">'
            .(($caption || $credit) ? '<figcaption>'.e($caption).$credit.'</figcaption>' : '').'</figure>';
    }
}
