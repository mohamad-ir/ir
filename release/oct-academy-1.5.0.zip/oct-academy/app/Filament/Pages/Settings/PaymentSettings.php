<?php

namespace App\Filament\Pages\Settings;

use App\Models\Page;
use App\Services\Payments\Fulfillment;
use App\Services\Payments\StripeClient;
use App\Services\Payments\StripeException;
use App\Services\Payments\StripeReferences;
use App\Support\Money;
use App\Support\Settings;
use Filament\Actions\Action;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Illuminate\Support\HtmlString;

class PaymentSettings extends SettingsPage
{
    protected static ?string $slug = 'settings/payments';

    protected static ?string $navigationLabel = 'Payment settings';

    protected static ?string $title = 'Payments & membership settings';

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-credit-card';

    protected static string|\UnitEnum|null $navigationGroup = 'Sales';

    protected static ?int $navigationSort = 9;

    protected function groups(): array
    {
        return ['payments', 'membership'];
    }

    protected function permission(): string
    {
        return 'sales.manage';
    }

    protected function mutateStateBeforeSave(array $state): array
    {
        if (($state['payments']['enabled'] ?? false) && blank($state['payments']['stripe_secret_key'] ?? null) && blank(Settings::get('payments.stripe_secret_key'))) {
            throw \Illuminate\Validation\ValidationException::withMessages(['data.payments.stripe_secret_key' => __('Add your Stripe secret key before switching payments on.')]);
        }

        return $state;
    }

    protected function afterSave(): void
    {
        if (StripeReferences::syncMode()) {
            Notification::make()->warning()->title(__('Stripe mode changed'))
                ->body(__('You switched between test and live keys. Customers, products and prices will be created again in the new mode. Remember to set up the webhook for this mode too.'))
                ->persistent()->send();
        }
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('test')->label(__('Test connection'))->icon('heroicon-o-signal')->color('gray')
                ->action(function () {
                    try {
                        $stripe = new StripeClient;
                        $account = $stripe->get('account');
                        $mode = $stripe->isTestMode() ? 'TEST mode' : 'LIVE mode';
                        $name = $account['settings']['dashboard']['display_name'] ?? $account['business_profile']['name'] ?? $account['id'];
                        $charges = ($account['charges_enabled'] ?? true) ? 'Payments enabled.' : 'Stripe has not yet enabled payments on this account — finish the account activation in Stripe.';
                        Notification::make()->success()->title("Connected to {$name} ({$mode})")->body($charges)->persistent()->send();
                    } catch (StripeException $e) {
                        Notification::make()->danger()->title(__('Connection failed'))->body($e->getMessage())->persistent()->send();
                    }
                }),
            Action::make('webhook')->label(__('Set up webhook automatically'))->icon('heroicon-o-bolt')
                ->requiresConfirmation()
                ->modalDescription(fn () => __('Creates a Stripe webhook that sends payment events to :url and saves its signing secret here.', ['url' => route('stripe.webhook')]).' '.__('Your website must be reachable on the internet at this address (it will not work on a local computer).'))
                ->action(function () {
                    try {
                        $stripe = new StripeClient;
                        $endpoint = $stripe->post('webhook_endpoints', [
                            'url' => route('stripe.webhook'),
                            'enabled_events' => Fulfillment::EVENTS,
                            'description' => Settings::get('site.name').' website',
                            'api_version' => StripeClient::API_VERSION,
                        ]);
                        if (($old = Settings::get('payments.webhook_endpoint_id')) && $old !== $endpoint['id']) {
                            try {
                                $stripe->delete('webhook_endpoints/'.$old);
                            } catch (StripeException) {
                                // The previous endpoint may belong to the other mode or already be gone.
                            }
                        }
                        Settings::set('payments.stripe_webhook_secret', $endpoint['secret'], true);
                        Settings::set('payments.webhook_endpoint_id', $endpoint['id']);
                        $this->mount();
                        Notification::make()->success()->title(__('Webhook created'))->body(__('Stripe will now notify the website about payments, renewals, cancellations and refunds.'))->send();
                    } catch (StripeException $e) {
                        Notification::make()->danger()->title(__('Could not create the webhook'))->body($e->getMessage())->persistent()->send();
                    }
                }),
        ];
    }

    protected function components(): array
    {
        $pages = fn () => Page::published()->orderBy('title')->get()->mapWithKeys(fn ($p) => ['/'.$p->slug => $p->title])->all();

        return [
            Section::make('Stripe')->heading(__('Stripe'))
                ->description(new HtmlString('Payments are processed by <a href="https://stripe.com" target="_blank" class="underline">Stripe</a> on its own secure checkout page, so card details never reach this server. Create a Stripe account, then copy the <strong>secret key</strong> from Developers › API keys. Start with a <strong>test key</strong> (sk_test_…) and use the card 4242 4242 4242 4242 to try a purchase.'))
                ->columns(2)->schema([
                    Toggle::make('payments.enabled')->label(__('Accept payments on the website'))->columnSpanFull()
                        ->helperText(__('While off, prices are shown but buttons say “opening soon”. Free courses and free webinars work either way.')),
                    TextInput::make('payments.stripe_secret_key')->label(__('Secret key'))->password()->revealable()
                        ->placeholder(fn (Get $get) => $get('payments.stripe_secret_key_set') ? __('•••••••• (saved — leave empty to keep)') : 'sk_test_… or sk_live_…')
                        ->rule('nullable')->regex('/^(sk|rk)_(test|live)_[A-Za-z0-9]+$/')
                        ->validationMessages(\App\Support\Ui::options(['regex' => 'This does not look like a Stripe secret key (sk_test_… or sk_live_…).'])),
                    TextInput::make('payments.stripe_webhook_secret')->label(__('Webhook signing secret'))->password()->revealable()
                        ->placeholder(fn (Get $get) => $get('payments.stripe_webhook_secret_set') ? __('•••••••• (saved — leave empty to keep)') : 'whsec_…')
                        ->helperText(__('Filled automatically by “Set up webhook automatically”.')),
                    Placeholder::make('webhook_url')->label(__('Webhook address'))->columnSpanFull()
                        ->content(fn () => new HtmlString('<code class="text-sm">'.e(route('stripe.webhook')).'</code><br><span class="text-xs text-gray-500">Events: '.e(implode(', ', Fulfillment::EVENTS)).'</span>')),
                ]),
            Section::make('Prices & tax')->heading(__('Prices & tax'))->columns(2)->schema([
                Select::make('payments.currency')->label(__('Main currency'))->options(\App\Support\Ui::options(Money::CURRENCIES))->selectablePlaceholder(false)
                    ->helperText(__('Used for new courses, tickets and plans, and for visitors whose currency has no price.')),
                \Filament\Forms\Components\CheckboxList::make('payments.currencies')->label(__('Currencies visitors can choose'))->options(\App\Support\Ui::options(Money::CURRENCIES))->columns(2)
                    ->helperText(__('Set the actual prices on each course, webinar and plan (“Prices in other currencies”). Stripe pays out in your bank currency and converts automatically.')),
                Toggle::make('payments.prices_include_tax')->label(__('Prices include VAT'))->inline(false)
                    ->helperText(__('Recommended for consumers in Europe: the price shown is the price paid.')),
                Toggle::make('payments.automatic_tax')->label(__('Calculate VAT automatically with Stripe Tax'))
                    ->helperText(__('Requires Stripe Tax to be activated (Stripe dashboard › Tax) and your tax registrations to be added there.')),
                Toggle::make('payments.collect_tax_id')->label(__('Let businesses enter a VAT number'))
                    ->helperText(__('Shown on the invoice; enables reverse charge with Stripe Tax.')),
                Toggle::make('payments.allow_promotion_codes')->label(__('Allow discount codes at checkout'))
                    ->helperText(__('Create codes in Stripe › Product catalogue › Coupons.')),
                Toggle::make('payments.invoice_one_time')->label(__('Create a formal invoice for course and ticket purchases'))
                    ->helperText(__('Stripe charges a small fee per invoice. Membership payments always get an invoice.')),
            ]),
            Section::make('Legal')->heading(__('Legal'))->columns(2)->schema([
                TextInput::make('payments.terms_url')->label(__('Terms of sale page'))->datalist(fn () => array_keys($pages()))->placeholder('/terms-of-sale')->maxLength(300),
                TextInput::make('payments.refund_url')->label(__('Refund policy page'))->datalist(fn () => array_keys($pages()))->placeholder('/refund-policy')->maxLength(300),
                Toggle::make('payments.withdrawal_waiver')->label(__('Ask EU/UK buyers to waive the 14-day withdrawal right for immediate access'))->columnSpanFull()
                    ->helperText(__('Required to start access immediately to digital content sold to consumers in the EU and UK. Keep on unless your adviser says otherwise.')),
            ]),
            Section::make('Membership page')->heading(__('Membership page'))->schema([
                TextInput::make('membership.heading')->label(__('Heading')),
                Textarea::make('membership.intro')->label(__('Introduction'))->rows(2),
                Repeater::make('membership.faq')->label(__('Questions & answers'))->schema([
                    TextInput::make('question')->required(),
                    Textarea::make('answer')->rows(2)->required(),
                ])->collapsible()->collapsed()->itemLabel(fn (array $state) => $state['question'] ?? null)->defaultItems(0),
            ]),
        ];
    }
}
