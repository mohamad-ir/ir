<?php

namespace App\Services\Theme;

use App\Support\Settings;
use Illuminate\Support\Facades\Cache;

/**
 * Converts the design settings chosen in the dashboard into CSS custom
 * properties. Every public component reads these tokens, so changes stay
 * inside the design system and never break responsive layouts.
 */
class ThemeService
{
    public const HEADING_FONTS = [
        'newsreader' => ['Newsreader', "'Newsreader Variable', Georgia, 'Times New Roman', serif"],
        'source-serif' => ['Source Serif 4', "'Source Serif 4 Variable', Georgia, serif"],
        'literata' => ['Literata', "'Literata Variable', Georgia, serif"],
        'fraunces' => ['Fraunces', "'Fraunces Variable', Georgia, serif"],
        'inter' => ['Inter', "'Inter Variable', ui-sans-serif, system-ui, sans-serif"],
        'ibm-plex' => ['IBM Plex Sans', "'IBM Plex Sans Variable', ui-sans-serif, system-ui, sans-serif"],
        'source-sans' => ['Source Sans 3', "'Source Sans 3 Variable', ui-sans-serif, system-ui, sans-serif"],
    ];

    public const BODY_FONTS = [
        'inter' => ['Inter', "'Inter Variable', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif"],
        'source-sans' => ['Source Sans 3', "'Source Sans 3 Variable', ui-sans-serif, system-ui, sans-serif"],
        'ibm-plex' => ['IBM Plex Sans', "'IBM Plex Sans Variable', ui-sans-serif, system-ui, sans-serif"],
        'source-serif' => ['Source Serif 4', "'Source Serif 4 Variable', Georgia, serif"],
        'literata' => ['Literata', "'Literata Variable', Georgia, serif"],
    ];

    public const RADII = ['none' => ['0', '0'], 'sm' => ['.25rem', '.375rem'], 'md' => ['.5rem', '.875rem'], 'lg' => ['.75rem', '1.375rem']];

    public const DENSITY = ['compact' => ['3rem', '4rem'], 'comfortable' => ['3.75rem', '6rem'], 'spacious' => ['4.5rem', '8rem']];

    public const CONTAINERS = ['narrow' => '68rem', 'standard' => '76rem', 'wide' => '86rem'];

    public const PRESETS = [
        'clinical-navy' => ['label' => 'Clinical navy (default)', 'primary' => '#12324f', 'accent' => '#0f8b8d', 'highlight' => '#d9822b', 'background' => '#fbfaf7', 'surface' => '#ffffff', 'text' => '#1c2733'],
        'deep-retina' => ['label' => 'Deep retina', 'primary' => '#1f2a44', 'accent' => '#b4413b', 'highlight' => '#e0a33a', 'background' => '#faf8f5', 'surface' => '#ffffff', 'text' => '#20242c'],
        'macula-green' => ['label' => 'Macula green', 'primary' => '#173a36', 'accent' => '#2f8f6f', 'highlight' => '#c98a2e', 'background' => '#f8faf8', 'surface' => '#ffffff', 'text' => '#1d2b28'],
        'iris-indigo' => ['label' => 'Iris indigo', 'primary' => '#24235a', 'accent' => '#5b5fc7', 'highlight' => '#e08b4c', 'background' => '#fafafd', 'surface' => '#ffffff', 'text' => '#1f2133'],
        'graphite' => ['label' => 'Graphite & cyan', 'primary' => '#1d2329', 'accent' => '#0e7fa6', 'highlight' => '#d4a017', 'background' => '#f7f8f9', 'surface' => '#ffffff', 'text' => '#1b1f24'],
    ];

    public function css(): string
    {
        // Dashboard theme preview: staff can render unsaved theme values via ?theme_preview=token.
        $token = request()?->query('theme_preview');
        if (is_string($token) && $token !== '' && auth()->user()?->isStaff() && is_array($draft = Cache::get('theme-preview:'.$token))) {
            return $this->build($draft);
        }

        return Cache::rememberForever('theme.css', fn () => $this->build(Settings::group('theme')));
    }

    public function build(array $t): string
    {
        $color = fn (string $key) => $this->sanitizeColor($t[$key] ?? null, Settings::get("theme.$key") ?? '#000000');

        $primary = $color('primary');
        $accent = $color('accent');
        $highlight = $color('highlight');
        $bg = $color('background');
        $surface = $color('surface');
        $text = $color('text');

        $heading = self::HEADING_FONTS[$t['heading_font'] ?? ''][1] ?? self::HEADING_FONTS['newsreader'][1];
        $body = self::BODY_FONTS[$t['body_font'] ?? ''][1] ?? self::BODY_FONTS['inter'][1];
        [$rUi, $rCard] = self::RADII[$t['radius'] ?? 'md'] ?? self::RADII['md'];
        [$spaceSm, $spaceLg] = self::DENSITY[$t['density'] ?? 'comfortable'] ?? self::DENSITY['comfortable'];
        $container = self::CONTAINERS[$t['container'] ?? 'standard'] ?? self::CONTAINERS['standard'];
        $base = max(15, min(20, (int) ($t['base_size'] ?? 17)));
        $btnRadius = match ($t['button_style'] ?? 'rounded') {
            'pill' => '999px',
            'square' => '0',
            default => $rUi,
        };

        $vars = [
            '--color-ink' => $primary,
            '--color-ink-contrast' => $this->contrastText($primary),
            '--color-accent' => $accent,
            '--color-accent-contrast' => $this->contrastText($accent),
            '--color-accent-ink' => $this->ensureContrast($accent, $bg),
            '--color-highlight' => $highlight,
            '--color-highlight-contrast' => $this->contrastText($highlight),
            '--color-paper' => $bg,
            '--color-surface' => $surface,
            '--color-fg' => $text,
            '--font-heading' => $heading,
            '--font-sans' => $body,
            '--radius-ui' => $rUi,
            '--radius-card' => $rCard,
            '--radius-btn' => $btnRadius,
            '--space-section-sm' => $spaceSm,
            '--space-section' => $spaceLg,
            '--container-site' => $container,
            '--font-size-root' => ($base / 16 * 100).'%',
        ];

        $vars['--color-highlight-ink'] = $this->ensureContrast($highlight, $bg);
        $vars['--color-logo-tile'] = $primary;

        // The light palette stays available inside dark pages for elements that sit on a white chip (e.g. play buttons).
        $light = ['--light-ink' => $primary, '--light-fg' => $text, '--light-paper' => $bg, '--light-surface' => $surface];

        $css = ':root{'.collect($vars + $light)->map(fn ($v, $k) => "{$k}:{$v}")->implode(';').'}';
        $css .= ':root.dark{'.collect($this->darkVars($t))->map(fn ($v, $k) => "{$k}:{$v}")->implode(';').'}';

        if (filled($t['custom_css'] ?? null)) {
            $css .= "\n".str_ireplace(['</style', '<script', 'javascript:', 'expression('], '', $t['custom_css']);
        }

        return $css;
    }

    /**
     * Dark palette derived from the brand colours, so a dark page still looks like this website.
     * The owner can override the three main surfaces in Theme & branding › Dark mode.
     *
     * @return array<string, string>
     */
    public function darkVars(array $t): array
    {
        $color = fn (string $key, string $default) => $this->sanitizeColor($t[$key] ?? null, Settings::get("theme.$key") ?? $default);
        $optional = fn (string $key) => filled($t[$key] ?? null) && preg_match('/^#[0-9a-f]{6}$/i', (string) $t[$key]) ? strtolower($t[$key]) : null;

        $primary = $color('primary', '#12324f');
        $accent = $color('accent', '#0f8b8d');
        $highlight = $color('highlight', '#d9822b');

        $paper = $optional('dark_background') ?? $this->mix('#0b1015', $primary, 0.16);
        $surface = $optional('dark_surface') ?? $this->mix($paper, '#ffffff', 0.045);
        $text = $optional('dark_text') ?? $this->mix('#dce3ea', $primary, 0.04);
        $heading = $this->mix($text, '#ffffff', 0.55);

        // Brand panels (dark header/footer, hero bands): the primary colour when it reads as a panel, otherwise lifted from the background.
        $panel = $this->luminance($primary) < 0.012 || $this->contrastRatio($primary, $paper) < 1.25
            ? $this->mix($paper, '#ffffff', 0.08)
            : $this->mix($primary, $paper, 0.25);

        return [
            'color-scheme' => 'dark',
            '--color-ink' => $heading,
            '--color-ink-contrast' => $paper,
            '--color-panel' => $panel,
            '--color-panel-contrast' => $this->contrastText($panel),
            '--color-accent-ink' => $this->ensureContrast($accent, $paper),
            '--color-highlight-ink' => $this->ensureContrast($highlight, $paper),
            '--color-paper' => $paper,
            '--color-surface' => $surface,
            '--color-fg' => $text,
            '--color-logo-tile' => $panel,
            '--shadow-card' => '0 1px 2px rgb(0 0 0 / .3), 0 1px 3px rgb(0 0 0 / .25)',
            '--shadow-lift' => '0 2px 4px rgb(0 0 0 / .3), 0 12px 28px -6px rgb(0 0 0 / .55)',
            '--shadow-pop' => '0 24px 60px -12px rgb(0 0 0 / .7)',
        ];
    }

    /** Mixes $b into $a by $amount (0–1) in sRGB. */
    public function mix(string $a, string $b, float $amount): string
    {
        $ca = array_map('hexdec', str_split(ltrim($a, '#'), 2));
        $cb = array_map('hexdec', str_split(ltrim($b, '#'), 2));

        return sprintf('#%02x%02x%02x', ...array_map(fn ($x, $y) => (int) round($x + ($y - $x) * $amount), $ca, $cb));
    }

    public function sanitizeColor(?string $value, string $fallback): string
    {
        $value = trim((string) $value);

        if (preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', $value)) {
            return strtolower(strlen($value) === 4 ? '#'.$value[1].$value[1].$value[2].$value[2].$value[3].$value[3] : $value);
        }

        return preg_match('/^#[0-9a-f]{6}$/i', $fallback) ? $fallback : '#000000';
    }

    public function luminance(string $hex): float
    {
        $hex = ltrim($hex, '#');
        $rgb = array_map(fn ($c) => hexdec($c) / 255, str_split($hex, 2));
        $rgb = array_map(fn ($c) => $c <= 0.03928 ? $c / 12.92 : (($c + 0.055) / 1.055) ** 2.4, $rgb);

        return 0.2126 * $rgb[0] + 0.7152 * $rgb[1] + 0.0722 * $rgb[2];
    }

    public function contrastRatio(string $a, string $b): float
    {
        $la = $this->luminance($a);
        $lb = $this->luminance($b);

        return round((max($la, $lb) + 0.05) / (min($la, $lb) + 0.05), 2);
    }

    public function contrastText(string $hex): string
    {
        return $this->contrastRatio($hex, '#ffffff') >= $this->contrastRatio($hex, '#111111') ? '#ffffff' : '#111111';
    }

    /** Darkens (or, on a dark background, lightens) a colour until it reaches WCAG AA (4.5:1), for accent-coloured text. */
    public function ensureContrast(string $hex, string $bg): string
    {
        $rgb = array_map('hexdec', str_split(ltrim($hex, '#'), 2));
        $lighten = $this->luminance($bg) < 0.18;
        $i = 0;
        while ($this->contrastRatio($hex, $bg) < 4.5 && $i++ < 30) {
            $rgb = $lighten
                ? array_map(fn ($c) => min(255, (int) round($c + (255 - $c) * 0.12)), $rgb)
                : array_map(fn ($c) => max(0, (int) round($c * 0.9)), $rgb);
            $hex = sprintf('#%02x%02x%02x', ...$rgb);
        }

        return $hex;
    }

    /** @return array<int, string> Human readable accessibility warnings for the dashboard. */
    public function audit(array $t): array
    {
        $warnings = [];
        $bg = $this->sanitizeColor($t['background'] ?? null, '#ffffff');
        $text = $this->sanitizeColor($t['text'] ?? null, '#111111');
        $primary = $this->sanitizeColor($t['primary'] ?? null, '#12324f');

        if (($r = $this->contrastRatio($text, $bg)) < 4.5) {
            $warnings[] = "Body text contrast is {$r}:1 — below the WCAG AA minimum of 4.5:1. Choose a darker text colour or a lighter background.";
        }
        if (($r = $this->contrastRatio($primary, $bg)) < 3) {
            $warnings[] = "The primary colour has only {$r}:1 contrast with the background, so headings and buttons may be hard to see.";
        }

        $dark = $this->darkVars($t);
        if (($r = $this->contrastRatio($dark['--color-fg'], $dark['--color-paper'])) < 4.5) {
            $warnings[] = "Dark mode: body text contrast is {$r}:1 — below 4.5:1. Choose a lighter dark-mode text colour or a darker dark-mode background.";
        }

        return $warnings;
    }
}
